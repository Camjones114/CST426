Battle3 is object type design pattern and can be ran in the battle3demo.java
the test can be ran in battle3test
this battle is a mix of dragons and orcs fighting the user