
/*
 * 
 * name: Cameron Jones
 * Cst 426
 * */
public class Battle3Demo 
{
	public static void main(String[] args)
	{
		Dragon drag1 = new Dragon();
		System.out.print("A dragon has come to battle");
		System.out.printf("%n");
		System.out.print("Dragon Health : "+drag1.getHp());
		System.out.printf("%n");
		System.out.print(drag1.attack());
		System.out.printf("%n");
		System.out.print("Attack dragon with epic spell (200 dmg)");
		System.out.printf("%n");
		drag1.attackDrag(200);
		
		Dragon drag2 = new Dragon();
		System.out.print("A dragon has come to battle");
		System.out.printf("%n");
		System.out.print("Dragon health: "+drag2.getHp());
		System.out.printf("%n");
		System.out.print(drag2.attack());
		System.out.printf("%n");
		drag2.attackDrag(40);
		System.out.print("Attack dragon with common spell (40 dmg)");
		System.out.printf("%n");
		System.out.print("Dragon health: "+drag2.getHp());
		
		Orc orc1 = new Orc();
		System.out.print("A orc has come to battle");
		System.out.printf("%n");
		System.out.print("Orc health: "+orc1.getHp());
		System.out.printf("%n");
		System.out.print(orc1.attack());
		System.out.printf("%n");
		System.out.print("Attack orc with sword (60 dmg)");
		System.out.printf("%n");
		orc1.attackOrc(60);
		System.out.print("Orc health: "+orc1.getHp());
		System.out.printf("%n");
		System.out.print(orc1.attack());
		Orc orc2 = new Orc();
		System.out.print("A orc has come to battle");
		System.out.printf("%n");
		System.out.print("Orc health: "+orc2.getHp());
		System.out.printf("%n");
		System.out.print(orc2.attack());
		System.out.print("Rage Activated : Destroy remaining creatures");
		System.out.printf("%n");
		orc1.attackOrc(500);
		orc2.attackOrc(500);
		drag2.attackDrag(500);
	}
	
}
