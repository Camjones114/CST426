/*
 * 
 * name: Cameron Jones
 * Cst 426
 * */
public class Orc implements Monster
{
	String name = "Orc";
	int health = monsterhp-50;
	@Override
	public String attack()
	{
		return "Orc uses Lunge Stab on you";
	}
	public int getHp()
	{
		return this.health;
	}
	
	public int attackOrc(int dmg)
	{
		int dmgHp = this.health;
		if (dmg > dmgHp)
		{
			System.out.print("Orc Defeated!");
			System.out.printf("%n");
			health=0;
			return health;
		}
		else
		health-= dmg;
		
		return health;
	}
}
