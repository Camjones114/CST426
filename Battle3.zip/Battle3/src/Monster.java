/*
 * 
 * name: Cameron Jones
 * Cst 426
 * */
public interface Monster 
{
	public int monsterhp = 200;
	
	public default String attack()
	{
		return "Monster attack";
	}
}
