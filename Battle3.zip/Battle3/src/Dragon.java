/*
 * 
 * name: Cameron Jones
 * Cst 426
 * */
public class Dragon implements Monster
{
	private String name = "Dragon";
	int health = monsterhp-10;
	@Override
	public String attack()
	{
		return " Dragon uses Fire Breath on you";
	}
	public int getHp()
	{
		return health;
	}
	public String getType()
	{
		return name;
	}
	public int attackDrag(int dmg)
	{
		int dmgHp = this.health;
		if (dmg > dmgHp)
		{
			System.out.print("Dragon Defeated!");
			System.out.printf("%n");
			health=0;
			return health;
		}
		else
		health-= dmg;
		
		return health;
	}
}
