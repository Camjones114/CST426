
public class EnemySniper extends EnemyPrototype
{
public EnemySniper()
	{
		enemyType = "Sniper";
		enemyHp = 100;
		enemyDamage = 100;
	}
	@Override
	void draw()
	{
		System.out.println("Caution: enemy Sniper spotted!");
		
	}
	@Override
	public EnemySniper clone()
	{
		System.out.println("cloneing enemy Sniper");
		return (EnemySniper) super.clone();
		
	}

}
