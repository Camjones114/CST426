
public class EnemyInfantry extends EnemyPrototype
{
	public EnemyInfantry()
	{
		enemyType = "Infantry ";
		enemyHp = 20;
		enemyDamage = 30;
	}
	@Override
	void draw() {
		System.out.println("Caution: hostile Infantry Inbound!");
		
	}
	@Override
	public EnemyInfantry clone()
	{
		System.out.println("cloneing enemy infantry");
		return (EnemyInfantry) super.clone();
		
	}

}
