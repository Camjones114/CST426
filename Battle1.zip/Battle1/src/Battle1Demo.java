
public class Battle1Demo 
{
	public static void main(String[] args)
	{
		
		EnemyInfantry clone1 = new EnemyInfantry();
		System.out.print("Enemy Infantry Spotted! ");
		System.out.printf("%n");
		int health;
		
		health=attack(clone1);
		clone1.setEnemyHp(health);
		
		EnemySniper clone2 = new EnemySniper();
		System.out.print("Enemy Sniper Spotted! ");
		System.out.printf("%n");
		health = attack(clone2);
		clone2.setEnemyHp(health);
		System.out.print("Enemy Scouting Report: ");
		System.out.printf("%n");
		System.out.print("Enemy Class: "+ clone1.getEnemyType());
		System.out.printf("%n");
		System.out.print("Current Hp: "+clone1.getEnemyHP());
		System.out.printf("%n");
		System.out.print("Enemy Class: "+ clone2.getEnemyType());
		System.out.printf("%n");
		System.out.print("Current Hp: "+clone2.getEnemyHP());
		System.out.printf("%n");
		
		
	}
	public static int attack(EnemyPrototype a)
	{
		int newHp;
		int attack = 30;
		newHp =a.getEnemyHP();
		if (newHp > attack)
		{
			newHp-=attack;
			return newHp;
		}
		
		else 
		{
			
			return 0;
		}
	}
}
