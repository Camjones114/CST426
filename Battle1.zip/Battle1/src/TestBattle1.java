
public class TestBattle1 
{
	public static void main(String[] args)
	{
		System.out.print("Calling spawn function ");
		System.out.printf("%n");
		EnemyInfantry clone1 = new EnemyInfantry();
		System.out.print("Enemy infantry Spawned ");
		System.out.printf("%n");
		
		int health;
		System.out.printf("start attack function");
		System.out.printf("%n");
		health=attack(clone1);
		
		System.out.printf("Setting new health to infantry after battle");
		System.out.printf("%n");
		clone1.setEnemyHp(health);
		
		System.out.printf("calling spawn function");
		System.out.printf("%n");
		EnemySniper clone2 = new EnemySniper();
		System.out.print("Enemy sniper spawned ");
		System.out.printf("%n");
		
		System.out.printf("calling attack function");
		System.out.printf("%n");
		health = attack(clone2);
		clone2.setEnemyHp(health);
		System.out.printf("setting new health to sniper after battle");
		System.out.printf("%n");
		
		System.out.printf("Call funtion to display a status update on the enemies");
		System.out.printf("%n");
		
		System.out.print("Enemy Scouting Report: ");
		System.out.printf("%n");
		
		System.out.printf("should display the enemy class as Infantry");
		System.out.printf("%n");
		
		System.out.print("Enemy Class: "+ clone1.getEnemyType());
		System.out.printf("%n");
		
		System.out.printf("should display the enemy hp as 0");
		System.out.printf("%n");
		
		System.out.print("Current Hp: "+clone1.getEnemyHP());
		System.out.printf("%n");
		
		System.out.printf("should display the enemy type as Sniper");
		System.out.printf("%n");
		
		System.out.print("Enemy Class: "+ clone2.getEnemyType());
		System.out.printf("%n");
		
		System.out.printf("should display the enemy hp as 70");
		System.out.printf("%n");
		
		System.out.print("Current Hp: "+clone2.getEnemyHP());
		System.out.printf("%n");
		
		
	}
	public static int attack(EnemyPrototype a)
	{
		int newHp;
		int attack = 30;
		newHp =a.getEnemyHP();
		if (newHp > attack)
		{
			newHp-=attack;
			return newHp;
		}
		
		else 
		{
			
			return 0;
		}
	}
}