
public abstract class EnemyPrototype implements Cloneable 
{
	protected String enemyType;
	protected int enemyHp;
	protected int enemyDamage;
	abstract void draw();
	
	 public String getEnemyType()
	 	{
	      return enemyType;
	 	}
	 public int getEnemyHP()
	 	{
	      return enemyHp;
	 	}
	 public int getEnemyDamage()
	 	{
	      return enemyDamage;
	 	}
	 public void setEnemyHp(int newHp)
	 	{
		 if (newHp > 0)
	      this.enemyHp = newHp;
		 else
		 {
			 this.enemyHp = 0;
			 System.out.print("Target destroyed ");
			 System.out.printf("%n");
		 }
	 	}
	public Object clone() 
		{
	      Object clone = null;
	      
	      try 
	      {
	         clone = super.clone();
	         
	      } 
	      catch (CloneNotSupportedException e) 
	      {
	         e.printStackTrace();
	      }
	      
	      return clone;
	   }
	
}
