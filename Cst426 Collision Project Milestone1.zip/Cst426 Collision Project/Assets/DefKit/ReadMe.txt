Prototype on collision on a non convex deformable bunny
this instance is a bunny object falling onto a floor plane to demonstrate collision. 
during the run you can move the camera using A,S,W,D controls and the mouse to rotate.
the colliders created in the ojbect are made of many smaller rigidbodies since the object is in a non convex shape.
press esc to exit